// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Model coldspring flow"); }
int main(){
  announce();
  return lionss_run_workload("coldspring");
}
