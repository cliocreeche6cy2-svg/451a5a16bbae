// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Propagate from TLE"); }
int main(){
  announce();
  return lionss_run_workload("tle-sgp4");
}
