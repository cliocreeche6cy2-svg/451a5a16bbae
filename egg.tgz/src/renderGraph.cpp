// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compile render graph"); }
int main(){
  announce();
  return lionss_run_workload("renderGraph");
}
