// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compute umbra region"); }
int main(){
  announce();
  return lionss_run_workload("umbra");
}
