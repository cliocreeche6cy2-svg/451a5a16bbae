// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Grow silver birch\n", stdout);
  return lionss_run_workload("SilverBirch");
}
